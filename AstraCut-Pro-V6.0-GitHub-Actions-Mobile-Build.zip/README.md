# AstraCut Pro V6.0 — Integrated Production Master

V6.0 is the integrated architecture target for AstraCut. It preserves the conceptual
architecture accumulated from V1.1 through V5.13 and combines the planned intermediate
milestones into one source tree.

## Preserved architecture
- Multi-track timeline, trim/split/ripple, history and project state.
- MediaExtractor/MediaCodec video path.
- SurfaceTexture / OES video texture path.
- EGL/OpenGL GPU composition.
- Video/image/text layers, z-order, transforms and opacity.
- Keyframes, Bézier/easing and animation evaluation.
- MediaCodec audio decode boundary.
- PCM ring buffer and multi-track PCM mixer.
- AudioTrack and hardware audio clock.
- Video frame pacing and audio-master synchronization.
- AI provider/job/timeline bridge architecture.
- Hardware encoder and MP4 muxing boundaries.
- Export state machine, cancellation, checkpoint/recovery and diagnostics.

## V6.0 integrated subsystems
1. Editing Core
2. Runtime Media Engine
3. GPU Composition
4. Animation Engine
5. Audio Engine
6. Synchronization
7. Export/Encoding
8. Effects/Transitions
9. AI Studio
10. Project Persistence/Recovery
11. Device Capability/Compatibility
12. Performance/Diagnostics
13. Test Architecture
14. Release Engineering

## Critical honesty note
This package is an integrated engineering source foundation, not proof that every
native codec/GPU path works on every Android device. A production claim requires
Gradle build, installation, instrumentation tests, real MediaCodec encoder/decoder
tests, EGL surface tests, AudioTrack tests, MP4 muxing tests, stress tests and
device-matrix validation.

The source deliberately uses adapter interfaces around hardware-dependent components.
Those adapters are the correct place to bind the concrete Android MediaCodec,
AudioTrack, EGL and MediaMuxer implementations without changing the timeline,
animation, synchronization and compositor architecture.


## Build / APK status
This environment does not contain the Android SDK or a Gradle runtime, so an APK cannot be truthfully claimed as built here. The project is prepared for Android Studio/Gradle synchronization.

Recommended first build: Android Studio → Open → select this project → Sync Project with Gradle Files → Build > Build APK(s). Android Studio/Gradle is the standard Android build path.
