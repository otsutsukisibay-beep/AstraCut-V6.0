# Build AstraCut V6.0 dari HP Android

## 1. Buat repository GitHub
Buat repository baru, misalnya:
`AstraCut-V6.0`

## 2. Upload isi project, BUKAN file ZIP sebagai satu file
Ekstrak paket ini terlebih dahulu di HP.
Di halaman repository GitHub pilih:
Add file → Upload files
Lalu upload isi folder project.
GitHub mendukung upload file melalui browser dan commit langsung ke repository.

Pastikan struktur teratas terlihat seperti:
- .github/
- app/
- build.gradle.kts
- settings.gradle.kts
- gradle.properties

## 3. Jalankan build cloud
Setelah semua file masuk ke branch `main`, buka:
Actions → AstraCut V6.0 Android Build → Run workflow

Workflow memakai GitHub-hosted runner dan Gradle 8.13.
Ia akan:
- checkout source
- menyiapkan Java 21
- menyiapkan Gradle
- menjalankan assembleDebug
- menjalankan unit test
- menyimpan APK sebagai artifact

## 4. Ambil APK
Jika workflow hijau:
Actions → pilih run terbaru → Artifacts →
`AstraCut-V6.0-debug-APK`

Download artifact tersebut ke HP, ekstrak ZIP artifact jika perlu, lalu install APK.

## Penting
Workflow ini membuktikan proses kompilasi dan unit test di cloud, bukan validasi semua
hardware Android. GPU/EGL, MediaCodec, AudioTrack, dan export MP4 tetap harus diuji
di perangkat nyata setelah APK terpasang.

Jangan upload password, API key, keystore, atau secret ke source repository.
